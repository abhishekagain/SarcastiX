"""
Script to run model training and prediction for Hinglish sarcasm detection
This script provides a command-line interface to train and predict with different models.
"""

import os
import sys
import argparse
import logging
import time

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler("run_models.log"),
        logging.StreamHandler()
    ]
)

logger = logging.getLogger("run-models")

def run_hinglish_bert_training():
    """Run Hinglish-BERT model training"""
    logger.info("Running Hinglish-BERT training...")
    
    try:
        # Change to the Hinglish-BERT directory
        os.chdir(os.path.join(os.path.dirname(os.path.abspath(__file__)), "hinglish-bert"))
        
        # Import and run the training script
        sys.path.insert(0, os.getcwd())
        from train import train_and_evaluate
        
        # Run training
        metrics = train_and_evaluate()
        
        logger.info("Hinglish-BERT training completed successfully")
        logger.info(f"Accuracy: {metrics['accuracy']:.4f}")
        logger.info(f"F1 Score: {metrics['f1']:.4f}")
        
        return True
    except Exception as e:
        logger.error(f"Error running Hinglish-BERT training: {str(e)}")
        return False
    finally:
        # Reset path and directory
        if os.getcwd() != os.path.dirname(os.path.abspath(__file__)):
            os.chdir(os.path.dirname(os.path.abspath(__file__)))
        if sys.path[0] != os.path.dirname(os.path.abspath(__file__)):
            sys.path.pop(0)

def run_muril_training():
    """Run MuRIL model training"""
    logger.info("Running MuRIL training...")
    
    try:
        # Change to the MuRIL directory
        os.chdir(os.path.join(os.path.dirname(os.path.abspath(__file__)), "muril"))
        
        # Import and run the training script
        sys.path.insert(0, os.getcwd())
        from train import train_and_evaluate
        
        # Run training
        metrics = train_and_evaluate()
        
        logger.info("MuRIL training completed successfully")
        logger.info(f"Accuracy: {metrics['accuracy']:.4f}")
        logger.info(f"F1 Score: {metrics['f1']:.4f}")
        
        return True
    except Exception as e:
        logger.error(f"Error running MuRIL training: {str(e)}")
        return False
    finally:
        # Reset path and directory
        if os.getcwd() != os.path.dirname(os.path.abspath(__file__)):
            os.chdir(os.path.dirname(os.path.abspath(__file__)))
        if sys.path[0] != os.path.dirname(os.path.abspath(__file__)):
            sys.path.pop(0)

def run_hinglish_bert_prediction(file_path, output_dir=None):
    """Run Hinglish-BERT model prediction"""
    logger.info(f"Running Hinglish-BERT prediction on {file_path}...")
    
    try:
        # Change to the Hinglish-BERT directory
        os.chdir(os.path.join(os.path.dirname(os.path.abspath(__file__)), "hinglish-bert"))
        
        # Import and run the prediction script
        sys.path.insert(0, os.getcwd())
        from predict import predict_from_file
        
        # Run prediction
        model_dir = os.path.join(os.getcwd(), "hinglish_bert_model")
        result = predict_from_file(file_path, model_dir, output_dir)
        
        logger.info("Hinglish-BERT prediction completed successfully")
        logger.info(f"Predictions saved to {result['predictions_path']}")
        
        if result.get('metrics'):
            logger.info(f"Accuracy: {result['metrics']['accuracy']:.4f}")
            logger.info(f"F1 Score: {result['metrics']['f1']:.4f}")
        
        return result
    except Exception as e:
        logger.error(f"Error running Hinglish-BERT prediction: {str(e)}")
        return {"success": False, "error": str(e)}
    finally:
        # Reset path and directory
        if os.getcwd() != os.path.dirname(os.path.abspath(__file__)):
            os.chdir(os.path.dirname(os.path.abspath(__file__)))
        if sys.path[0] != os.path.dirname(os.path.abspath(__file__)):
            sys.path.pop(0)

def run_muril_prediction(file_path, output_dir=None):
    """Run MuRIL model prediction"""
    logger.info(f"Running MuRIL prediction on {file_path}...")
    
    try:
        # Change to the MuRIL directory
        os.chdir(os.path.join(os.path.dirname(os.path.abspath(__file__)), "muril"))
        
        # Import and run the prediction script
        sys.path.insert(0, os.getcwd())
        from predict import predict_from_file
        
        # Run prediction
        model_dir = os.path.join(os.getcwd(), "muril_model")
        result = predict_from_file(file_path, model_dir, output_dir)
        
        logger.info("MuRIL prediction completed successfully")
        logger.info(f"Predictions saved to {result['predictions_path']}")
        
        if result.get('metrics'):
            logger.info(f"Accuracy: {result['metrics']['accuracy']:.4f}")
            logger.info(f"F1 Score: {result['metrics']['f1']:.4f}")
        
        return result
    except Exception as e:
        logger.error(f"Error running MuRIL prediction: {str(e)}")
        return {"success": False, "error": str(e)}
    finally:
        # Reset path and directory
        if os.getcwd() != os.path.dirname(os.path.abspath(__file__)):
            os.chdir(os.path.dirname(os.path.abspath(__file__)))
        if sys.path[0] != os.path.dirname(os.path.abspath(__file__)):
            sys.path.pop(0)

def run_model_comparison(dataset_path=None):
    """Run model comparison"""
    logger.info("Running model comparison...")
    
    try:
        # Import and run the comparison script
        from compare_models import compare_metrics, compare_confusion_matrices, compare_on_dataset
        
        # Run comparison
        compare_metrics()
        compare_confusion_matrices()
        
        if dataset_path:
            compare_on_dataset(dataset_path)
        
        logger.info("Model comparison completed successfully")
        return True
    except Exception as e:
        logger.error(f"Error running model comparison: {str(e)}")
        return False

def main():
    """Main function to parse arguments and run the appropriate script"""
    parser = argparse.ArgumentParser(description="Run model training and prediction for Hinglish sarcasm detection")
    
    # Create subparsers for different commands
    subparsers = parser.add_subparsers(dest="command", help="Command to run")
    
    # Train parser
    train_parser = subparsers.add_parser("train", help="Train a model")
    train_parser.add_argument("model", choices=["hinglish-bert", "muril", "all"], help="Model to train")
    
    # Predict parser
    predict_parser = subparsers.add_parser("predict", help="Make predictions with a model")
    predict_parser.add_argument("model", choices=["hinglish-bert", "muril", "all"], help="Model to use for prediction")
    predict_parser.add_argument("file", help="Path to the file to predict on")
    predict_parser.add_argument("--output", help="Output directory for predictions")
    
    # Compare parser
    compare_parser = subparsers.add_parser("compare", help="Compare models")
    compare_parser.add_argument("--dataset", help="Path to the dataset to compare on")
    
    # Parse arguments
    args = parser.parse_args()
    
    # Run the appropriate command
    if args.command == "train":
        if args.model == "hinglish-bert":
            run_hinglish_bert_training()
        elif args.model == "muril":
            run_muril_training()
        elif args.model == "all":
            run_hinglish_bert_training()
            run_muril_training()
    
    elif args.command == "predict":
        if args.model == "hinglish-bert":
            run_hinglish_bert_prediction(args.file, args.output)
        elif args.model == "muril":
            run_muril_prediction(args.file, args.output)
        elif args.model == "all":
            run_hinglish_bert_prediction(args.file, args.output)
            run_muril_prediction(args.file, args.output)
            run_model_comparison(args.file)
    
    elif args.command == "compare":
        run_model_comparison(args.dataset)
    
    else:
        parser.print_help()

if __name__ == "__main__":
    logger.info("Starting run_models.py")
    start_time = time.time()
    
    main()
    
    # Calculate and log execution time
    execution_time = time.time() - start_time
    logger.info(f"Execution completed in {execution_time:.2f} seconds")
