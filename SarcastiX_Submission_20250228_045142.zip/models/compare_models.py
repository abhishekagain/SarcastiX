"""
Model Comparison Script for Hinglish Sarcasm Detection
This script compares the performance of different models for Hinglish sarcasm detection.
"""

import os
import json
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
import logging
import time
import sys

# Import model prediction modules
sys.path.append(os.path.join(os.path.dirname(os.path.abspath(__file__)), "hinglish-bert"))
sys.path.append(os.path.join(os.path.dirname(os.path.abspath(__file__)), "muril"))

from hinglish_bert.predict import predict_from_file as predict_hinglish_bert
from muril.predict import predict_from_file as predict_muril

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler("model_comparison.log"),
        logging.StreamHandler()
    ]
)

logger = logging.getLogger("model-comparison")

# Constants
HINGLISH_BERT_MODEL_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "hinglish-bert")
MURIL_MODEL_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "muril")
OUTPUT_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "comparison_results")

# Create output directory if it doesn't exist
os.makedirs(OUTPUT_DIR, exist_ok=True)

def load_model_metrics(model_name):
    """Load metrics for a specific model"""
    metrics_file = os.path.join(os.path.dirname(os.path.abspath(__file__)), model_name, "metrics.json")
    
    try:
        with open(metrics_file, 'r') as f:
            metrics = json.load(f)
        return metrics
    except Exception as e:
        logger.error(f"Error loading metrics for {model_name}: {str(e)}")
        return None

def compare_metrics():
    """Compare metrics from different models"""
    # Load metrics
    hinglish_bert_metrics = load_model_metrics("hinglish-bert")
    muril_metrics = load_model_metrics("muril")
    
    if not hinglish_bert_metrics or not muril_metrics:
        logger.error("Failed to load metrics for one or more models")
        return
    
    # Create comparison dataframe
    comparison = pd.DataFrame({
        'Metric': ['Accuracy', 'Precision', 'Recall', 'F1 Score'],
        'Hinglish-BERT': [
            hinglish_bert_metrics['accuracy'],
            hinglish_bert_metrics['precision'],
            hinglish_bert_metrics['recall'],
            hinglish_bert_metrics['f1']
        ],
        'MuRIL': [
            muril_metrics['accuracy'],
            muril_metrics['precision'],
            muril_metrics['recall'],
            muril_metrics['f1']
        ]
    })
    
    # Save comparison to CSV
    comparison_path = os.path.join(OUTPUT_DIR, "metrics_comparison.csv")
    comparison.to_csv(comparison_path, index=False)
    logger.info(f"Metrics comparison saved to {comparison_path}")
    
    # Create bar chart
    plt.figure(figsize=(12, 8))
    comparison_melted = pd.melt(comparison, id_vars=['Metric'], var_name='Model', value_name='Score')
    sns.barplot(x='Metric', y='Score', hue='Model', data=comparison_melted)
    plt.title('Model Performance Comparison')
    plt.ylim(0, 1)
    plt.tight_layout()
    
    # Save chart
    chart_path = os.path.join(OUTPUT_DIR, "metrics_comparison.png")
    plt.savefig(chart_path)
    plt.close()
    logger.info(f"Comparison chart saved to {chart_path}")
    
    # Print comparison
    print("\nModel Performance Comparison:")
    print(comparison.to_string(index=False))
    
    return comparison

def compare_confusion_matrices():
    """Compare confusion matrices from different models"""
    # Load metrics
    hinglish_bert_metrics = load_model_metrics("hinglish-bert")
    muril_metrics = load_model_metrics("muril")
    
    if not hinglish_bert_metrics or not muril_metrics:
        logger.error("Failed to load metrics for one or more models")
        return
    
    # Create figure with subplots
    fig, axes = plt.subplots(1, 2, figsize=(20, 8))
    
    # Plot Hinglish-BERT confusion matrix
    sns.heatmap(
        np.array(hinglish_bert_metrics['confusion_matrix']), 
        annot=True, 
        fmt='d', 
        cmap='Blues',
        xticklabels=['Non-Sarcastic', 'Sarcastic'],
        yticklabels=['Non-Sarcastic', 'Sarcastic'],
        ax=axes[0]
    )
    axes[0].set_xlabel('Predicted')
    axes[0].set_ylabel('Actual')
    axes[0].set_title('Hinglish-BERT Confusion Matrix')
    
    # Plot MuRIL confusion matrix
    sns.heatmap(
        np.array(muril_metrics['confusion_matrix']), 
        annot=True, 
        fmt='d', 
        cmap='Blues',
        xticklabels=['Non-Sarcastic', 'Sarcastic'],
        yticklabels=['Non-Sarcastic', 'Sarcastic'],
        ax=axes[1]
    )
    axes[1].set_xlabel('Predicted')
    axes[1].set_ylabel('Actual')
    axes[1].set_title('MuRIL Confusion Matrix')
    
    plt.tight_layout()
    
    # Save comparison
    comparison_path = os.path.join(OUTPUT_DIR, "confusion_matrix_comparison.png")
    plt.savefig(comparison_path)
    plt.close()
    logger.info(f"Confusion matrix comparison saved to {comparison_path}")

def compare_on_dataset(dataset_path):
    """Compare models on a specific dataset"""
    logger.info(f"Comparing models on dataset: {dataset_path}")
    
    start_time = time.time()
    
    # Create model-specific output directories
    hinglish_bert_output = os.path.join(OUTPUT_DIR, "hinglish-bert")
    muril_output = os.path.join(OUTPUT_DIR, "muril")
    os.makedirs(hinglish_bert_output, exist_ok=True)
    os.makedirs(muril_output, exist_ok=True)
    
    # Run predictions with both models
    logger.info("Running Hinglish-BERT predictions...")
    hinglish_bert_result = predict_hinglish_bert(
        dataset_path, 
        HINGLISH_BERT_MODEL_DIR, 
        hinglish_bert_output
    )
    
    logger.info("Running MuRIL predictions...")
    muril_result = predict_muril(
        dataset_path, 
        MURIL_MODEL_DIR, 
        muril_output
    )
    
    # Check if both models produced metrics (requires labeled data)
    if hinglish_bert_result.get('metrics') and muril_result.get('metrics'):
        # Create comparison dataframe
        comparison = pd.DataFrame({
            'Metric': ['Accuracy', 'Precision', 'Recall', 'F1 Score'],
            'Hinglish-BERT': [
                hinglish_bert_result['metrics']['accuracy'],
                hinglish_bert_result['metrics']['precision'],
                hinglish_bert_result['metrics']['recall'],
                hinglish_bert_result['metrics']['f1']
            ],
            'MuRIL': [
                muril_result['metrics']['accuracy'],
                muril_result['metrics']['precision'],
                muril_result['metrics']['recall'],
                muril_result['metrics']['f1']
            ]
        })
        
        # Save comparison to CSV
        comparison_path = os.path.join(OUTPUT_DIR, "dataset_comparison.csv")
        comparison.to_csv(comparison_path, index=False)
        logger.info(f"Dataset comparison saved to {comparison_path}")
        
        # Create bar chart
        plt.figure(figsize=(12, 8))
        comparison_melted = pd.melt(comparison, id_vars=['Metric'], var_name='Model', value_name='Score')
        sns.barplot(x='Metric', y='Score', hue='Model', data=comparison_melted)
        plt.title(f'Model Performance Comparison on {os.path.basename(dataset_path)}')
        plt.ylim(0, 1)
        plt.tight_layout()
        
        # Save chart
        chart_path = os.path.join(OUTPUT_DIR, "dataset_comparison.png")
        plt.savefig(chart_path)
        plt.close()
        logger.info(f"Dataset comparison chart saved to {chart_path}")
        
        # Print comparison
        print(f"\nModel Performance Comparison on {os.path.basename(dataset_path)}:")
        print(comparison.to_string(index=False))
        
        # Compare confusion matrices
        fig, axes = plt.subplots(1, 2, figsize=(20, 8))
        
        # Plot Hinglish-BERT confusion matrix
        sns.heatmap(
            np.array(hinglish_bert_result['metrics']['confusion_matrix']), 
            annot=True, 
            fmt='d', 
            cmap='Blues',
            xticklabels=['Non-Sarcastic', 'Sarcastic'],
            yticklabels=['Non-Sarcastic', 'Sarcastic'],
            ax=axes[0]
        )
        axes[0].set_xlabel('Predicted')
        axes[0].set_ylabel('Actual')
        axes[0].set_title('Hinglish-BERT Confusion Matrix')
        
        # Plot MuRIL confusion matrix
        sns.heatmap(
            np.array(muril_result['metrics']['confusion_matrix']), 
            annot=True, 
            fmt='d', 
            cmap='Blues',
            xticklabels=['Non-Sarcastic', 'Sarcastic'],
            yticklabels=['Non-Sarcastic', 'Sarcastic'],
            ax=axes[1]
        )
        axes[1].set_xlabel('Predicted')
        axes[1].set_ylabel('Actual')
        axes[1].set_title('MuRIL Confusion Matrix')
        
        plt.tight_layout()
        
        # Save comparison
        cm_comparison_path = os.path.join(OUTPUT_DIR, "dataset_cm_comparison.png")
        plt.savefig(cm_comparison_path)
        plt.close()
        logger.info(f"Dataset confusion matrix comparison saved to {cm_comparison_path}")
    else:
        logger.warning("Dataset does not contain labels for evaluation. Only predictions were generated.")
    
    # Calculate and log comparison time
    comparison_time = time.time() - start_time
    logger.info(f"Comparison completed in {comparison_time:.2f} seconds")

if __name__ == "__main__":
    logger.info("Starting model comparison script")
    
    # Compare model metrics
    compare_metrics()
    
    # Compare confusion matrices
    compare_confusion_matrices()
    
    # Compare on dataset if provided
    if len(sys.argv) > 1:
        dataset_path = sys.argv[1]
        compare_on_dataset(dataset_path)
    
    logger.info("Model comparison completed successfully")
