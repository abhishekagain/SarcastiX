# SarcastiX Model Collection

This directory contains the implementation of various models for sarcasm detection in Hinglish (Hindi-English mixed) text.

## Available Models

### 1. Hinglish-BERT

A fine-tuned version of the [AI4Bharat/indic-bert](https://huggingface.co/ai4bharat/indic-bert) model, specifically optimized for detecting sarcasm in Hinglish text.

- **Accuracy**: 94.12%
- **F1 Score**: 94.19%
- **Use Case**: Hinglish Sentiment + Sarcasm

[View Hinglish-BERT Documentation](./hinglish-bert/README.md)

### 2. MuRIL

A fine-tuned version of [google/muril-base-cased](https://huggingface.co/google/muril-base-cased), a multilingual model specifically pre-trained on 17 Indian languages and their transliterated counterparts.

- **Accuracy**: 95.32%
- **F1 Score**: 95.19%
- **Use Case**: Indian Languages + Hinglish

[View MuRIL Documentation](./muril/README.md)

## Submission Package

This model collection is part of the SarcastiX submission package that includes:

1. **Complete Prediction Pipeline**:
   - Scripts to load models and make predictions
   - Tools to evaluate model performance
   - Integration with the SarcastiX backend

2. **Trained Models**:
   - Model files (`.bin`, `.json`)
   - Tokenizers (`.pkl`)
   - Configuration files

3. **Classification Reports & Confusion Matrices**:
   - Performance metrics for each model
   - Visual representations of model predictions
   - Comparative analysis between models

## Real-time Dataset Processing

All models are designed to process real-time datasets provided in `.csv` or `.xlsx` format:

```bash
python run_models.py predict [model_name] path/to/dataset.csv
```

The prediction pipeline will:
1. Load the specified model
2. Process the dataset
3. Generate predictions with confidence scores
4. Create a classification report (accuracy, precision, recall, F1-score)
5. Generate a confusion matrix visualization
6. Save all results to an output directory

## Model Comparison

We provide a script to compare the performance of different models:

```bash
python compare_models.py [optional_dataset_path]
```

This script generates:
1. A comparison of metrics (accuracy, precision, recall, F1 score) between models
2. Visualizations of confusion matrices for each model
3. If a dataset is provided, a comparison of model performance on that specific dataset

## Directory Structure

```
models/
├── compare_models.py          # Script to compare model performance
├── hinglish-bert/             # Hinglish-BERT model implementation
│   ├── train.py               # Training script
│   ├── predict.py             # Prediction script
│   ├── integration.py         # Backend integration script
│   ├── hinglish_bert_model/   # Saved model files
│   ├── metrics.json           # Performance metrics
│   ├── confusion_matrix.png   # Visualization of model performance
│   └── README.md              # Model documentation
├── muril/                     # MuRIL model implementation
│   ├── train.py               # Training script
│   ├── predict.py             # Prediction script
│   ├── integration.py         # Backend integration script
│   ├── muril_model/           # Saved model files
│   ├── metrics.json           # Performance metrics
│   ├── confusion_matrix.png   # Visualization of model performance
│   └── README.md              # Model documentation
├── run_models.py              # CLI for running models
└── README.md                  # This file
```

## Usage

Each model directory contains its own training and prediction scripts. To use a model:

1. Navigate to the model directory
2. Run the prediction script with your data:
   ```bash
   python predict.py path/to/your/data.csv
   ```

For integration with the SarcastiX backend, each model provides an `integration.py` script that demonstrates how to register the model with the backend and use it for predictions.

## Running All Models

To run predictions with all models and compare their performance:

```bash
python run_models.py predict all path/to/dataset.csv
```

This will:
1. Run predictions with each model
2. Generate individual model reports
3. Create a comparative analysis
4. Save all results in a structured format

## Model Selection Guide

- **Hinglish-BERT**: Best for general Hinglish text with a good balance of Hindi and English
- **MuRIL**: Superior for text with multiple Indian languages or heavy use of transliteration

## Dependencies

Each model directory contains its own `requirements.txt` file with the specific dependencies needed for that model. In general, all models require:

- PyTorch
- Transformers
- Pandas
- NumPy
- Scikit-learn
- Matplotlib
- Seaborn
