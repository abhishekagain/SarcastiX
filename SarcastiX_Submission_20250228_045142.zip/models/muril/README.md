# MuRIL for Sarcasm Detection

This directory contains the implementation of a MuRIL model for sarcasm detection in Hinglish (Hindi-English mixed) text.

## Model Description

MuRIL (Multilingual Representations for Indian Languages) is a multilingual model specifically pre-trained on 17 Indian languages and their transliterated counterparts. This implementation fine-tunes the [google/muril-base-cased](https://huggingface.co/google/muril-base-cased) model for sarcasm detection in Hinglish text.

The model is particularly effective for:
- Processing text with multiple Indian languages and their transliterations
- Handling code-mixed content in social media
- Capturing cultural nuances in Indian language expressions

## Directory Structure

```
muril/
├── train.py                # Training script
├── predict.py              # Prediction script
├── muril_model/           # Saved model files
│   ├── config.json
│   ├── pytorch_model.bin
│   └── vocab.txt
├── tokenizer.pkl           # Serialized tokenizer
├── metrics.json            # Performance metrics
├── confusion_matrix.png    # Visualization of model performance
└── README.md               # This file
```

## Performance Metrics

- **Accuracy**: 0.95
- **Precision**: 0.94
- **Recall**: 0.96
- **F1 Score**: 0.95

## Submission Package Contents

This model is part of the submission package that includes:

1. **Trained Model Files**:
   - The complete MuRIL model (`muril_model/`)
   - Serialized tokenizer (`tokenizer.pkl`)

2. **Classification Report**:
   - Comprehensive metrics in `metrics.json`
   - Includes accuracy, precision, recall, and F1-score

3. **Confusion Matrix**:
   - Visual representation in `confusion_matrix.png`
   - Shows true positives, true negatives, false positives, and false negatives

4. **Prediction Pipeline**:
   - Complete code for making predictions (`predict.py`)
   - Integration with SarcastiX backend (`integration.py`)

## Real-time Dataset Processing

The model is designed to process real-time datasets provided in `.csv` or `.xlsx` format:

```bash
python predict.py path/to/your/data.csv [model_dir] [output_dir]
```

The prediction script will:
1. Load the dataset
2. Process each text entry
3. Generate sarcasm predictions (0 = non-sarcastic, 1 = sarcastic)
4. Calculate confidence scores
5. Create a classification report and confusion matrix (if labels are provided)
6. Save all results to the specified output directory

## Usage

### Training

To train the model on your own dataset:

```bash
python train.py
```

By default, the script looks for training data at `../../datasets/train.csv`. You can modify the `TRAIN_DATA_PATH` constant in the script to point to your own dataset.

### Prediction

To make predictions on a new dataset:

```bash
python predict.py path/to/your/data.csv [model_dir] [output_dir]
```

For interactive prediction on single texts:

```bash
python predict.py
```

## Input Data Format

The model expects input data in CSV or Excel format with at least a 'text' column containing the Hinglish text to classify. For training or evaluation, a 'label' column is also required, where:
- 0 = Non-sarcastic
- 1 = Sarcastic

## Output

The prediction script generates:
1. A CSV file with the original data plus prediction columns
2. A JSON file with classification metrics (if labels were provided)
3. A confusion matrix visualization (if labels were provided)

## Dependencies

- PyTorch
- Transformers
- Pandas
- NumPy
- Scikit-learn
- Matplotlib
- Seaborn

## Advantages of MuRIL over Other Models

- Better understanding of Indian languages and their transliterations
- Improved performance on code-mixed content
- Enhanced ability to capture cultural context in expressions
- Robust handling of various Indian scripts and their Roman transliterations

## Citation

If you use this model in your research, please cite:

```
@inproceedings{khanuja2021muril,
  title={MuRIL: Multilingual Representations for Indian Languages},
  author={Khanuja, Simran and Bansal, Diksha and Mehtani, Sarvesh and Khosla, Savya and Dey, Atreyee and Gopalan, Balaji and Margam, Dilip Kumar and Aggarwal, Pooja and Nagipogu, Richa Tiwari Sneha and Dave, Shachi and others},
  booktitle={Proceedings of the 1st Workshop on Multi-lingual Representation Learning (MRL)},
  pages={97--111},
  year={2021}
}
