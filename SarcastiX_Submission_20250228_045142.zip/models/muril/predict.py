"""
MuRIL Model Prediction Script for Sarcasm Detection
This script uses a trained MuRIL model to predict sarcasm in Hinglish text.
"""

import os
import pandas as pd
import numpy as np
import torch
from torch.utils.data import Dataset, DataLoader
from transformers import AutoTokenizer, AutoModelForSequenceClassification
from sklearn.metrics import accuracy_score, precision_recall_fscore_support, confusion_matrix
import matplotlib.pyplot as plt
import seaborn as sns
import pickle
import logging
import json
import sys
import time

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler("muril_prediction.log"),
        logging.StreamHandler()
    ]
)

logger = logging.getLogger("muril-predict")

# Set device
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
logger.info(f"Using device: {device}")

# Constants
MAX_LEN = 128
BATCH_SIZE = 32
MODEL_DIR = "./"  # Directory where model is saved

class SarcasmDataset(Dataset):
    """Dataset class for Hinglish sarcasm data"""
    
    def __init__(self, texts, labels=None, tokenizer=None, max_len=128):
        self.texts = texts
        self.labels = labels
        self.tokenizer = tokenizer
        self.max_len = max_len
    
    def __len__(self):
        return len(self.texts)
    
    def __getitem__(self, idx):
        text = str(self.texts[idx])
        
        encoding = self.tokenizer.encode_plus(
            text,
            add_special_tokens=True,
            max_length=self.max_len,
            return_token_type_ids=True,
            padding='max_length',
            truncation=True,
            return_attention_mask=True,
            return_tensors='pt'
        )
        
        item = {
            'text': text,
            'input_ids': encoding['input_ids'].flatten(),
            'attention_mask': encoding['attention_mask'].flatten(),
            'token_type_ids': encoding['token_type_ids'].flatten(),
        }
        
        if self.labels is not None:
            item['labels'] = torch.tensor(self.labels[idx], dtype=torch.long)
            
        return item

def load_model_and_tokenizer(model_dir):
    """Load the trained model and tokenizer"""
    logger.info(f"Loading model and tokenizer from {model_dir}")
    
    try:
        model_path = os.path.join(model_dir, "muril_model")
        model = AutoModelForSequenceClassification.from_pretrained(model_path)
        model.to(device)
        
        # Try to load tokenizer from pickle file first
        tokenizer_path = os.path.join(model_dir, "tokenizer.pkl")
        if os.path.exists(tokenizer_path):
            with open(tokenizer_path, "rb") as f:
                tokenizer = pickle.load(f)
        else:
            # Fall back to loading from the saved model directory
            tokenizer = AutoTokenizer.from_pretrained(model_path)
        
        logger.info("Model and tokenizer loaded successfully")
        return model, tokenizer
    except Exception as e:
        logger.error(f"Error loading model and tokenizer: {str(e)}")
        raise

def predict(model, data_loader, device):
    """Make predictions using the trained model"""
    model.eval()
    predictions = []
    prediction_probs = []
    real_values = []
    texts = []
    
    with torch.no_grad():
        for batch in data_loader:
            texts.extend(batch['text'])
            input_ids = batch['input_ids'].to(device)
            attention_mask = batch['attention_mask'].to(device)
            token_type_ids = batch['token_type_ids'].to(device)
            
            outputs = model(
                input_ids=input_ids,
                attention_mask=attention_mask,
                token_type_ids=token_type_ids
            )
            
            logits = outputs.logits
            probs = torch.nn.functional.softmax(logits, dim=1)
            _, preds = torch.max(logits, dim=1)
            
            predictions.extend(preds.cpu().numpy())
            prediction_probs.extend(probs.cpu().numpy())
            
            if 'labels' in batch:
                real_values.extend(batch['labels'].cpu().numpy())
    
    return {
        'texts': texts,
        'predictions': predictions,
        'prediction_probs': prediction_probs,
        'real_values': real_values if real_values else None
    }

def generate_classification_report(predictions, real_values):
    """Generate a classification report"""
    accuracy = accuracy_score(real_values, predictions)
    precision, recall, f1, _ = precision_recall_fscore_support(
        real_values, predictions, average='binary'
    )
    cm = confusion_matrix(real_values, predictions)
    
    report = {
        'accuracy': float(accuracy),
        'precision': float(precision),
        'recall': float(recall),
        'f1': float(f1),
        'confusion_matrix': cm.tolist()
    }
    
    return report

def save_confusion_matrix(cm, output_path):
    """Save confusion matrix as an image"""
    plt.figure(figsize=(10, 8))
    sns.heatmap(cm, annot=True, fmt='d', cmap='Blues', 
                xticklabels=['Non-Sarcastic', 'Sarcastic'],
                yticklabels=['Non-Sarcastic', 'Sarcastic'])
    plt.xlabel('Predicted')
    plt.ylabel('Actual')
    plt.title('Confusion Matrix')
    plt.tight_layout()
    plt.savefig(output_path)
    plt.close()

def predict_from_file(file_path, model_dir=MODEL_DIR, output_dir=None):
    """Predict sarcasm from a file"""
    start_time = time.time()
    
    # Set output directory
    if output_dir is None:
        output_dir = os.path.join(os.path.dirname(file_path), "predictions")
    os.makedirs(output_dir, exist_ok=True)
    
    # Load model and tokenizer
    model, tokenizer = load_model_and_tokenizer(model_dir)
    
    # Load data
    logger.info(f"Loading data from {file_path}")
    try:
        if file_path.endswith('.csv'):
            df = pd.read_csv(file_path)
        elif file_path.endswith(('.xls', '.xlsx')):
            df = pd.read_excel(file_path)
        else:
            raise ValueError("Unsupported file format. Please provide a .csv or .xlsx file.")
        
        logger.info(f"Data loaded successfully with {len(df)} rows")
    except Exception as e:
        logger.error(f"Error loading data: {str(e)}")
        raise
    
    # Check if the required column exists
    if 'text' not in df.columns:
        logger.error("Required column 'text' not found in the dataset")
        raise ValueError("Required column 'text' not found in the dataset")
    
    # Check if label column exists for evaluation
    has_labels = 'label' in df.columns
    
    # Create dataset and dataloader
    texts = df['text'].values
    labels = df['label'].values if has_labels else None
    
    dataset = SarcasmDataset(texts, labels, tokenizer, MAX_LEN)
    data_loader = DataLoader(dataset, batch_size=BATCH_SIZE)
    
    # Make predictions
    logger.info("Making predictions...")
    result = predict(model, data_loader, device)
    
    # Add predictions to dataframe
    df['prediction'] = result['predictions']
    df['prediction_confidence'] = [probs[pred] for pred, probs in zip(result['predictions'], result['prediction_probs'])]
    
    # Save predictions to CSV
    output_csv_path = os.path.join(output_dir, "predictions.csv")
    df.to_csv(output_csv_path, index=False)
    logger.info(f"Predictions saved to {output_csv_path}")
    
    # Generate and save classification report if labels are available
    if has_labels:
        logger.info("Generating classification report...")
        report = generate_classification_report(result['predictions'], result['real_values'])
        
        # Save report to JSON
        report_path = os.path.join(output_dir, "classification_report.json")
        with open(report_path, 'w') as f:
            json.dump(report, f, indent=4)
        logger.info(f"Classification report saved to {report_path}")
        
        # Save confusion matrix
        cm_path = os.path.join(output_dir, "confusion_matrix.png")
        save_confusion_matrix(np.array(report['confusion_matrix']), cm_path)
        logger.info(f"Confusion matrix saved to {cm_path}")
        
        # Log metrics
        logger.info(f"Accuracy: {report['accuracy']:.4f}")
        logger.info(f"Precision: {report['precision']:.4f}")
        logger.info(f"Recall: {report['recall']:.4f}")
        logger.info(f"F1 Score: {report['f1']:.4f}")
    
    # Calculate and log prediction time
    prediction_time = time.time() - start_time
    logger.info(f"Prediction completed in {prediction_time:.2f} seconds")
    
    return {
        'predictions_path': output_csv_path,
        'report_path': report_path if has_labels else None,
        'confusion_matrix_path': cm_path if has_labels else None,
        'metrics': report if has_labels else None
    }

def predict_text(text, model_dir=MODEL_DIR):
    """Predict sarcasm for a single text input"""
    # Load model and tokenizer
    model, tokenizer = load_model_and_tokenizer(model_dir)
    
    # Tokenize input
    encoding = tokenizer.encode_plus(
        text,
        add_special_tokens=True,
        max_length=MAX_LEN,
        return_token_type_ids=True,
        padding='max_length',
        truncation=True,
        return_attention_mask=True,
        return_tensors='pt'
    )
    
    # Prepare input tensors
    input_ids = encoding['input_ids'].to(device)
    attention_mask = encoding['attention_mask'].to(device)
    token_type_ids = encoding['token_type_ids'].to(device)
    
    # Make prediction
    model.eval()
    with torch.no_grad():
        outputs = model(
            input_ids=input_ids,
            attention_mask=attention_mask,
            token_type_ids=token_type_ids
        )
        
        logits = outputs.logits
        probs = torch.nn.functional.softmax(logits, dim=1)
        _, preds = torch.max(logits, dim=1)
    
    # Get prediction and confidence
    prediction = preds.item()
    confidence = probs[0][prediction].item()
    
    return {
        'text': text,
        'prediction': prediction,
        'prediction_label': 'Sarcastic' if prediction == 1 else 'Non-Sarcastic',
        'confidence': confidence
    }

if __name__ == "__main__":
    logger.info("Starting MuRIL prediction script")
    
    if len(sys.argv) > 1:
        # Predict from file
        file_path = sys.argv[1]
        model_dir = sys.argv[2] if len(sys.argv) > 2 else MODEL_DIR
        output_dir = sys.argv[3] if len(sys.argv) > 3 else None
        
        result = predict_from_file(file_path, model_dir, output_dir)
        logger.info(f"Predictions saved to {result['predictions_path']}")
    else:
        # Interactive mode for single text prediction
        logger.info("No file provided. Entering interactive mode.")
        model, tokenizer = load_model_and_tokenizer(MODEL_DIR)
        
        while True:
            text = input("\nEnter text to predict (or 'exit' to quit): ")
            if text.lower() == 'exit':
                break
                
            result = predict_text(text)
            print(f"\nText: {result['text']}")
            print(f"Prediction: {result['prediction_label']}")
            print(f"Confidence: {result['confidence']:.4f}")
    
    logger.info("Prediction completed successfully")
