# Hinglish-BERT for Sarcasm Detection

This directory contains the implementation of a Hinglish-BERT model for sarcasm detection in Hinglish (Hindi-English mixed) text.

## Model Description

Hinglish-BERT is a fine-tuned version of the [AI4Bharat/indic-bert](https://huggingface.co/ai4bharat/indic-bert) model, specifically optimized for detecting sarcasm in Hinglish text. The model is particularly effective for:

- Social media content in Hinglish
- Sentiment analysis with sarcasm detection
- Mixed Hindi-English text processing

## Directory Structure

```
hinglish-bert/
├── train.py                # Training script
├── predict.py              # Prediction script
├── hinglish_bert_model/    # Saved model files
│   ├── config.json
│   ├── pytorch_model.bin
│   └── vocab.txt
├── tokenizer.pkl           # Serialized tokenizer
├── metrics.json            # Performance metrics
├── confusion_matrix.png    # Visualization of model performance
└── README.md               # This file
```

## Performance Metrics

- **Accuracy**: 0.94
- **Precision**: 0.93
- **Recall**: 0.95
- **F1 Score**: 0.94

## Submission Package Contents

This model is part of the submission package that includes:

1. **Trained Model Files**:
   - The complete Hinglish-BERT model (`hinglish_bert_model/`)
   - Serialized tokenizer (`tokenizer.pkl`)

2. **Classification Report**:
   - Comprehensive metrics in `metrics.json`
   - Includes accuracy, precision, recall, and F1-score

3. **Confusion Matrix**:
   - Visual representation in `confusion_matrix.png`
   - Shows true positives, true negatives, false positives, and false negatives

4. **Prediction Pipeline**:
   - Complete code for making predictions (`predict.py`)
   - Integration with SarcastiX backend (`integration.py`)

## Real-time Dataset Processing

The model is designed to process real-time datasets provided in `.csv` or `.xlsx` format:

```bash
python predict.py path/to/your/data.csv [model_dir] [output_dir]
```

The prediction script will:
1. Load the dataset
2. Process each text entry
3. Generate sarcasm predictions (0 = non-sarcastic, 1 = sarcastic)
4. Calculate confidence scores
5. Create a classification report and confusion matrix (if labels are provided)
6. Save all results to the specified output directory

## Usage

### Training

To train the model on your own dataset:

```bash
python train.py
```

By default, the script looks for training data at `../../datasets/train.csv`. You can modify the `TRAIN_DATA_PATH` constant in the script to point to your own dataset.

### Prediction

To make predictions on a new dataset:

```bash
python predict.py path/to/your/data.csv [model_dir] [output_dir]
```

For interactive prediction on single texts:

```bash
python predict.py
```

## Input Data Format

The model expects input data in CSV or Excel format with at least a 'text' column containing the Hinglish text to classify. For training or evaluation, a 'label' column is also required, where:
- 0 = Non-sarcastic
- 1 = Sarcastic

## Output

The prediction script generates:
1. A CSV file with the original data plus prediction columns
2. A JSON file with classification metrics (if labels were provided)
3. A confusion matrix visualization (if labels were provided)

## Dependencies

- PyTorch
- Transformers
- Pandas
- NumPy
- Scikit-learn
- Matplotlib
- Seaborn

## Citation

If you use this model in your research, please cite:

```
@misc{hinglish-bert-sarcasm,
  author = {SarcastiX Team},
  title = {Hinglish-BERT for Sarcasm Detection},
  year = {2025},
  publisher = {GitHub},
  journal = {GitHub Repository},
  howpublished = {\url{https://github.com/sarcastix/hinglish-bert-sarcasm}}
}
